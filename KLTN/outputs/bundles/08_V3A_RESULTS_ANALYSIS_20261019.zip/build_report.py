"""Present the completed CPU audit; never runs a model."""
from pathlib import Path
import csv
import json
import zipfile
import hashlib

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent


def rows(name):
    with (ROOT / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main():
    audit = json.loads((ROOT / "AUDIT.json").read_text(encoding="utf-8"))
    assert audit["status"] == "PASS"
    metrics = rows("recomputed_metrics_all_15_models.csv")
    summary = rows("recomputed_summary_mean_sample_SD.csv")
    probe = rows("selector_probe_recomputed_by_class.csv")
    trajectory = rows("beta_trajectory.csv")
    cls_delta = rows("V3_minus_full_M4_V2_per_class.csv")
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.4))
    colors = {42: "#2674a6", 43: "#d47e20", 44: "#579a50"}
    for seed in (42, 43, 44):
        vals = [float(next(r for r in metrics if r["method"] == m and int(r["seed"]) == seed)["Macro_F1"]) * 100 for m in ("learned_local", "V3-A")]
        ax[0].plot([0, 1], vals, "o-", color=colors[seed], label=f"Seed {seed}", linewidth=2)
        for x, y in enumerate(vals):
            dy = -16 if seed == 44 and x == 0 else 8
            ax[0].annotate(f"{y:.2f}", (x, y), xytext=(-8 if x == 0 else 8, dy), textcoords="offset points", ha="right" if x == 0 else "left", color=colors[seed])
    ax[0].set(xticks=[0, 1], xticklabels=["Historical full M4 V2", "V3-A"], ylabel="Test Macro-F1 (%)", xlim=(-.35, 1.35), ylim=(78, 89), title="V3-A lower in all three seed comparisons")
    ax[0].legend(frameon=False, loc="upper right")
    labels = {"V3-A": "V3-A", "learned_local": "V2 Learned-local", "random_local": "Random-local", "original_gan": "Original GAN", "matched_ros": "Matched ROS"}
    a = sorted(summary, key=lambda r: float(r["Macro_F1_mean"]))
    for i, r in enumerate(a):
        ax[1].errorbar(float(r["Macro_F1_mean"]) * 100, i,
                       xerr=float(r["Macro_F1_sample_SD"]) * 100, fmt="o",
                       color="#c55353" if r["method"] == "V3-A" else "#698ba3", capsize=4)
    ax[1].set_yticks(range(len(a)), [labels[r["method"]] for r in a])
    ax[1].set(xlim=(75, 88), xlabel="Test Macro-F1 (%), mean ± sample SD over 3 seeds", title="Same Protocol B and fixed 8,000 C-update budget")
    fig.text(.5, .015, "Historical recipe comparison; identical initial states / random traces are not established. Test B was already viewed.", ha="center", fontsize=9)
    fig.tight_layout(rect=(0, .06, 1, 1))
    fig.savefig(ROOT / "V3A_vs_V2_results.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(1, 3, figsize=(12.5, 4.3))
    probe_summary = []
    for seed in (42, 43, 44):
        selected = []
        for count in (200, 8000):
            data = [r for r in probe if int(r["seed"]) == seed and int(r["c_updates"]) == count]
            item = {"seed": seed, "c_updates": count, "anchors": 105, "triplets": 840,
                    "entropy_mean": float(np.mean([float(r["entropy_mean"]) for r in data])),
                    "max_weight_mean": float(np.mean([float(r["max_weight_mean"]) for r in data])),
                    "min_max_weight": min(float(r["max_weight_min"]) for r in data),
                    "noise_changing_anchors": sum(int(r["noise_changing_anchors"]) for r in data),
                    "raw_corrected_argmax_changes": sum(int(r["raw_corrected_argmax_changes"]) for r in data),
                    "raw_top2_gap_mean": float(np.mean([float(r["raw_top2_gap_mean"]) for r in data])),
                    "distance_bias_range_mean": float(np.mean([float(r["distance_bias_range_mean"]) for r in data])),
                    "G_feature_noise_RMS_mean": float(np.mean([float(r["G_feature_noise_RMS_mean"]) for r in data])),
                    "patch_noise_RMS_mean": float(np.mean([float(r["patch_noise_RMS_mean"]) for r in data]))}
            probe_summary.append(item)
            selected.append(item)
        ax[0].plot([0, 1], [r["entropy_mean"] for r in selected], "o-", color=colors[seed], label=f"Seed {seed}")
        ax[1].plot([0, 1], [selected[-1]["distance_bias_range_mean"], selected[-1]["raw_top2_gap_mean"]], "o-", color=colors[seed])
    ax[0].set(yscale="log", xticks=[0, 1], xticklabels=["200", "8,000"], xlabel="C updates", ylabel="Mean weight entropy (nats, log scale)", title="Near one-hot weights at 8,000")
    ax[0].legend(frameon=False)
    ax[1].set(yscale="log", xticks=[0, 1], xticklabels=["Distance-bias\nrange", "Raw top-2\nlogit gap"], ylabel="Mean magnitude (log scale)", title="Endpoint distance term is much smaller")
    for seed in (42, 43, 44):
        for cls in sorted({int(r["class_id"]) for r in trajectory}):
            data = sorted([r for r in trajectory if int(r["seed"]) == seed and int(r["class_id"]) == cls], key=lambda r: int(r["c_updates"]))
            ax[2].plot([int(r["c_updates"]) for r in data], [float(r["beta"]) for r in data], color=colors[seed], alpha=.4, linewidth=1)
    ax[2].axhline(0, color="black", linewidth=.7)
    ax[2].set(xlabel="C updates", ylabel="Signed beta (15 heads per seed)", title="Beta learns, then changes little late")
    fig.text(.5, .015, "Fixed train-only probe: 15 heads × 7 anchors × 8 noises per seed/checkpoint. Descriptive evidence; not a causal account of test accuracy.", ha="center", fontsize=9)
    fig.tight_layout(rect=(0, .06, 1, 1))
    fig.savefig(ROOT / "V3A_selector_diagnostics.png", dpi=180)
    plt.close(fig)
    with (ROOT / "selector_probe_summary.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(probe_summary[0])); w.writeheader(); w.writerows(probe_summary)

    lines = ["# V3-A — kết quả đã kiểm tra từ output gốc", "", 
        "**Lượt chạy đã hoàn tất. V3-A không cải thiện full M4 V2 trong thí nghiệm này; giữ V2 làm phương án chính đã có kết quả.**", "",
        "Đã train đủ 3 seed 42/43/44, mỗi seed 8.000 classifier updates, và test đủ 4.721 mẫu. Tổng thời gian do suite ghi nhận: **3 giờ 27 phút 44 giây** (12.464,11 giây). Không cần train hoặc inference lại để có các bảng dưới đây.", "",
        "## 1. Kết quả phân loại", "", "Trung bình ± độ lệch chuẩn mẫu qua 3 seed. Các chỉ số phần trăm là 100 × giá trị gốc.", "",
        "| Phương pháp | OA (%) | AA (%) | Macro-F1 (%) | GM (%) | Kappa |", "|---|---:|---:|---:|---:|---:|"]
    for r in summary:
        cells = [f"{float(r[k+'_mean'])*100:.3f} ± {float(r[k+'_sample_SD'])*100:.3f}" for k in ("OA", "AA", "Macro_F1", "GM")]
        lines.append("| " + labels[r["method"]] + " | " + " | ".join(cells) + f" | {float(r['Kappa_mean']):.4f} ± {float(r['Kappa_sample_SD']):.4f} |")
    lines += ["", "| Seed | V2 Macro-F1 (%) | V3-A Macro-F1 (%) | V3-A − V2 (điểm %) |", "|---:|---:|---:|---:|"]
    for seed in (42, 43, 44):
        v2, v3 = [next(r for r in metrics if r["method"] == method and int(r["seed"]) == seed) for method in ("learned_local", "V3-A")]
        lines.append(f"| {seed} | {float(v2['Macro_F1'])*100:.3f} | {float(v3['Macro_F1'])*100:.3f} | {(float(v3['Macro_F1'])-float(v2['Macro_F1']))*100:+.3f} |")
    lines += ["", "**Chênh lệch trung bình: −1,465 điểm phần trăm Macro-F1; V3-A thắng 0/3 so sánh theo seed.** OA trung bình giảm 0,643 điểm %, AA giảm 1,558 điểm %, GM giảm 3,584 điểm %. NLL (0,9857 so với 0,8916) và Brier (0,2149 so với 0,2062) cũng kém hơn; hai chỉ số này càng thấp càng tốt.", "",
        "Độ lệch chuẩn Macro-F1 của V3-A nhỏ hơn V2, nhưng trung bình thấp hơn. Điều này chưa đủ để gọi V3-A ổn định hơn nói chung và không bù được việc chưa đạt mục tiêu cải thiện.", "",
        "![So sánh kết quả](V3A_vs_V2_results.png)", "", "## 2. Kiểm tra kỹ thuật và độ đầy đủ", "",
        f"- Đã đọc toàn bộ {audit['members']} thành viên ZIP, kiểm CRC và SHA-256; không thấy hỏng file hoặc trùng tên thành viên.",
        "- Source trong ZIP khớp byte với bản notebook đã bàn giao. Frozen M4 không bị sửa.",
        "- Cả ba job có đúng method V3-A, protocol B `50e988fae260`, seed và cấu hình `k=3`, `rho=0.2`, 15 beta; checkpoint cuối và classifier khớp các hash đã khóa.",
        "- Có checkpoint đầy đủ ở 200, 7.500 và 8.000 cho cả ba seed; hai file weights và metadata của từng mốc đều kiểm hash được. Ba classifier H5 cuối đã lưu đủ.",
        "- Báo cáo runtime ghi pilot PASS; seed 42 được restore ở tiến trình mới và kiểm toàn bộ trạng thái native chính xác. Mỗi seed có kiểm 34 route thực đầu tiên, gồm weights, BatchNorm và Adam slots của mạng bị freeze.",
        "- Mỗi seed đủ C=8.000, D=8.000, GC=60.000, GD=60.000 và tổng shared-Adam calls=136.000. Báo cáo train ghi không mở validation/test.",
        "- Có 3 NPZ predictions gồm `y_true`, `y_pred`, `probabilities`, `coords`, confusion matrix; có CSV metrics từng seed và từng lớp. Tính lại tất cả 7 độ đo khớp báo cáo.",
        "- Đã mở lại predictions M4 gốc của đủ 12 model, kiểm nhãn/tọa độ trùng V3 và tính lại baseline; không chỉ tin bảng baseline nhúng trong notebook.",
        f"- {audit['checks_passed']} điều kiện kiểm tra file/số liệu đã qua. Đây là kiểm tra CPU trên artifact đã lưu, **không phải số lần chạy mô hình**. Không thực hiện TensorFlow restore hoặc forward mới ở máy local.",
        "", "## 3. Beta và selector đã học gì?", "",
        "Cả 45 beta (15 head × 3 seed) đều hữu hạn, có thay đổi từ khởi tạo 0 và có tổng bình phương gradient dương. Log ghi 8.000 lần có gradient kết nối cho mỗi beta; điều này không có nghĩa mọi gradient ở cuối train đều khác 0 hoặc hữu ích.", "",
        "Từ logits thực do Dense head sinh đã lưu trong NPZ, kiểm lại `corrected = raw − beta × standardized_distance` khớp. So sánh giữa mốc 200 và 8.000 dùng đúng cùng anchor IDs, neighbor IDs, noise và standardized distances ở cả ba seed.", "",
        "| Seed | Entropy ở 200 | Entropy ở 8.000 | Anchor đổi argmax theo noise: 200 → 8.000 |", "|---:|---:|---:|---:|"]
    for seed in (42, 43, 44):
        a, b = [next(r for r in probe_summary if r["seed"] == seed and r["c_updates"] == c) for c in (200, 8000)]
        lines.append(f"| {seed} | {a['entropy_mean']:.6f} | {b['entropy_mean']:.3g} | {a['noise_changing_anchors']}/105 → {b['noise_changing_anchors']}/105 |")
    lines += ["", "Ở mốc 8.000, max weight trung bình trên probe đều trên 0,9999997. G feature và raw logits vẫn thay đổi theo noise, trong khi weights và patch gần như không đổi theo noise khi giữ anchor cố định.", "",
        "Distance-bias range trung bình cuối train khoảng **0,087–0,094**, nhỏ hơn nhiều so với raw top-two logit gap trung bình **23,9–30,0**. Trong toàn bộ probe ở cả 200 và 8.000, thêm bias không đổi argmax so với raw logits (0/840 triplet cho mỗi seed/mốc). Điều này chỉ mô tả tác động tức thời của bias ở các điểm đã đo; **không có nghĩa beta không thể tác động vào quỹ đạo huấn luyện**.", "",
        "Trong 500 C updates cuối (7.500 → 8.000), beta thay đổi tuyệt đối tối đa lần lượt khoảng 8,72×10⁻⁶; 9,18×10⁻⁶; 1,55×10⁻⁴ ở seed 42/43/44. Không có quan sát entropy tại 7.500 trong probe mới này, nên không dùng các beta đó để suy ra entropy 7.500.", "",
        "**Kết luận cơ chế có giới hạn:** distance bias được triển khai và học được, nhưng trong recipe này chưa ngăn được hiện tượng weights gần one-hot ở endpoint trên các probe đã khóa. Chưa chứng minh đó là nguyên nhân khiến Macro-F1 giảm. Probe chỉ có 7 anchor/head × 8 noise; không thay thế khảo sát toàn bộ support.", "",
        "![Chẩn đoán selector](V3A_selector_diagnostics.png)", "", "## 4. Lớp nào giảm?", "",
        "| Seed | Số lớp F1 tăng / giảm / bằng | Giảm F1 lớn nhất | Đóng góp vào chênh Macro-F1 |", "|---:|---:|---|---:|"]
    for seed in (42, 43, 44):
        r = [v for v in cls_delta if int(v["seed"]) == seed]
        up = sum(float(v["F1_delta_pp"]) > 1e-12 for v in r)
        down = sum(float(v["F1_delta_pp"]) < -1e-12 for v in r)
        tie = 16 - up - down
        worst = min(r, key=lambda v: float(v["F1_delta_pp"]))
        lines.append(f"| {seed} | {up} / {down} / {tie} | {worst['class_name']}: {float(worst['F1_delta_pp']):+.3f} điểm % | {float(worst['Macro_F1_contribution_pp']):+.3f} điểm % |")
    lines += ["", "Đây là phân rã số học từ confusion matrices, không phải giải thích nhân quả. Các lớp rất nhỏ có ít test pixels nên F1/recall dễ dao động. Chi tiết đủ 48 dòng trong `V3_minus_full_M4_V2_per_class.csv`.", "",
        "## 5. Phạm vi kết luận và quyết định", "",
        "Baseline đối chiếu là **full M4 Learned-local V2** cùng protocol, train data, graph và ngân sách. Không phải C-only endpoint ablation; không trộn kết quả của hai loại thí nghiệm.", "",
        "Đây là so sánh với M4 lịch sử, không tuyên bố mọi initialization/chuỗi lấy mẫu/dropout đều paired-identical. Seed 43/44 của M4 cũ có khác phiên bản NumPy và tf-keras; các khác biệt descriptor đã được lưu rõ trong `historical_M4_comparison_limits.json`. Vì vậy không quy toàn bộ chênh lệch riêng cho beta.", "",
        "Test B đã được xem trước và có chồng lấn không gian. Kết quả này mô tả thí nghiệm hậu nghiệm đã cố định; không xác nhận generalization trên spatial split độc lập, không khẳng định ý nghĩa thống kê từ 3 seed và không giải quyết bài toán leakage.", "",
        "**Quyết định được dữ liệu hiện tại hỗ trợ:** không chọn V3-A thay V2. Giữ V2 cùng các hạn chế đã biết; trình bày V3-A như một biến thể đã kiểm nghiệm nhưng không cải thiện trong cấu hình này. Lượt này đã trả lời mục tiêu thực nghiệm của V3-A; không cần mở thêm lượt GPU để hoàn tất hoặc cứu kết quả.", "",
        "Mọi thay đổi beta/loss/temperature sau khi đã đọc các kết quả này sẽ là một ứng viên mới, không sửa lại kết luận của lượt đã hoàn tất.", "",
        "## 6. File gốc và khả năng phục hồi", "",
        f"- ZIP gốc: `{audit['source_path']}`.", f"- Dung lượng: {audit['source_bytes']:,} bytes.", f"- SHA-256: `{audit['source_sha256']}`.",
        "- ZIP gốc giữ toàn bộ checkpoint Generator/heads/C/D/shared optimizer ở 200/7.500/8.000, classifier cuối, source, telemetry và predictions. Giữ ZIP này để có thể phục hồi mô hình; gói phân tích nhẹ bên cạnh không thay thế checkpoint.",
        "- `received/` là các source/JSON/log/test output nhỏ sao chép nguyên byte để đọc tiện. Các CSV bắt đầu `recomputed_` được tính lại từ predictions gốc; không huấn luyện lại.",
        "- `analyze_backup_cpu.py` tái tạo audit/CSV; `build_report.py` tạo báo cáo/hình. Không có lựa chọn tham số hoặc đánh giá test mới trong hai script này.", ""]
    (ROOT / "KET_QUA_V3A.md").write_text("\n".join(lines), encoding="utf-8")
    bundle = ROOT.parent / "V3A_RESULTS_ANALYSIS_20261019.zip"
    with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(ROOT.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                z.write(p, p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(bundle) as z:
        assert z.testzip() is None
    digest = hashlib.sha256(bundle.read_bytes()).hexdigest()
    print(json.dumps({"report": str(ROOT / "KET_QUA_V3A.md"), "analysis_zip": str(bundle), "bytes": bundle.stat().st_size, "sha256": digest}, ensure_ascii=False))


if __name__ == "__main__":
    main()
