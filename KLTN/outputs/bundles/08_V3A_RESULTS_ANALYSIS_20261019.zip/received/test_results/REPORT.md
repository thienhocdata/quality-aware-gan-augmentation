# V3-A — kết quả một lượt chạy

**COMPLETE: 3/3 V3 classifiers, mỗi seed 8.000 C updates.**

| Method | OA (%) | AA (%) | Macro-F1 (%) | GM (%) | Kappa |
|---|---:|---:|---:|---:|---:|
| V3-A | 87.609 ± 1.175 | 84.489 ± 1.001 | 81.543 ± 1.701 | 78.208 ± 1.202 | 0.8593 ± 0.0134 |
| learned_local | 88.251 ± 1.229 | 86.046 ± 1.801 | 83.009 ± 3.015 | 81.793 ± 3.888 | 0.8668 ± 0.0139 |
| matched_ros | 87.143 ± 0.422 | 85.049 ± 0.681 | 81.485 ± 0.967 | 80.575 ± 3.269 | 0.8542 ± 0.0045 |
| original_gan | 87.552 ± 0.444 | 85.783 ± 1.641 | 81.663 ± 2.877 | 82.086 ± 4.027 | 0.8587 ± 0.0053 |
| random_local | 88.018 ± 1.199 | 86.016 ± 1.062 | 82.226 ± 3.004 | 81.862 ± 3.919 | 0.8644 ± 0.0134 |

V3-A − full M4 V2: mean Macro-F1 -1.465 điểm phần trăm; thắng 0/3 seed.

Báo đủ từng seed và cả kết quả không thuận lợi. Baseline là full M4 V2, không phải C-only endpoint. Đây là đối chiếu hậu nghiệm trong Protocol B có chồng lấn không gian; không tuyên bố paired-identical, tính mới, ý nghĩa thống kê hay lợi ích nhân quả riêng của distance bias. NLL dùng clipping 1e-12, float64 cho cả baseline và V3.

Mỗi classifier có NPZ chứa y_true, y_pred, probabilities, coords và confusion_matrix; metrics/per-class/mean±sampleSD/deltas đều lưu riêng. Không chọn seed tốt nhất hoặc tự sửa mô hình sau test.
