# Bằng chứng về V2, V3-A và phạm vi có thể kết luận

## 1. V2 tốt hơn baseline ở độ đo chính

Trong các kết quả full M4 đã tính lại từ predictions gốc, Macro-F1 trung bình của Learned-local V2 là 83,0085504%, cao hơn original GAN 81,6631650%, chênh +1,3453854 điểm phần trăm. Đây là cải thiện thực nghiệm ở độ đo chính trên Protocol B đã chạy. Không phủ nhận kết quả đó vì weights gần one-hot.

Weights gần one-hot và ít đổi theo noise là hành vi quan sát được. Chưa có bằng chứng nhân quả rằng chính các hành vi này kéo Macro-F1 của V2 xuống. Vì vậy chỉ có thể xem chúng là giả thuyết hạn chế cần kiểm chứng; không nên mặc định sửa chúng sẽ nâng Macro-F1.

## 2. Bằng chứng trực tiếp về phần distance bias

Đã kiểm lại logits và weights thực lưu trong sáu probe (3 seed × 2 mốc), không chạy mô hình hoặc test lại. Tại 8.000 updates, mỗi seed có 840 quan sát = 15 head × 7 anchor × 8 noise.

Gọi t là neighbor thắng theo raw logits, m là khoảng cách giữa logit cao nhất và cao thứ hai, và b = max_j |beta(q_t - q_j)|. Khi m > b, số hạng distance bias không thể đổi neighbor thắng trên đầu vào đang xét.

| Seed | Raw top-two gap nhỏ nhất | Hiệu chỉnh tương đối lớn nhất b | Số quan sát thỏa m > b |
|---:|---:|---:|---:|
| 42 | 14,375452 | 0,204880 | 840/840 |
| 43 | 9,172537 | 0,148531 | 840/840 |
| 44 | 12,391861 | 0,206087 | 840/840 |

Đây là kiểm trên từng quan sát, không suy từ việc so sánh hai số trung bình. Các corrected logits lưu thực tế cũng xác nhận 0/2.520 lần đổi argmax. Giữ nguyên G/head V3 cuối rồi chỉ bỏ beta trong phép tính làm thay đổi weights rất nhỏ: L1 trung bình mỗi triplet lần lượt khoảng 2,39e-10; 5,97e-8; 3,78e-9.

Kết luận được hỗ trợ: ở các đầu vào probe cuối này, bias quá yếu để thay đổi neighbor được chọn; V3-A chưa thay đổi hành vi endpoint theo kỳ vọng. Đây là so sánh có/không beta trên cùng logits V3, không phải so toàn bộ checkpoint V3 với checkpoint V2 gốc. Không suy rộng ra mọi anchor hoặc mọi thời điểm huấn luyện.

Ở mốc 200, weights có thể thay đổi do beta (L1 tối đa khoảng 0,0101; 0,0202; 0,0264), dù top-1 vẫn không đổi trong probe. Do đó không thể suy ngược từ endpoint rằng beta hoàn toàn không ảnh hưởng quá trình train.

## 3. Nguyên nhân Macro-F1 giảm chưa được cô lập

Kết quả đã xác nhận V3-A thấp hơn V2 ở cả ba seed, trung bình -1,4653641 điểm phần trăm. Nó chưa xác nhận distance bias hoặc softmax saturation là nguyên nhân.

M4 lịch sử và V3 khớp dữ liệu, graph, rho/k, budget và recipe chính. Tuy nhiên report/contract V2 gốc của cả ba seed không lưu hash initialization để xác nhận bằng byte; seed 43/44 còn khác NumPy, tf-keras và schedule descriptor. Các báo cáo hiện có chưa thiết lập rằng hai thí nghiệm chỉ khác duy nhất beta. Giải thích bằng 'quỹ đạo học thay đổi' vẫn chỉ là giả thuyết.

Muốn kết luận nhân quả riêng cho distance bias, đối chứng cần cùng runtime, khởi tạo các mạng chung, dữ liệu, lịch class/anchor/noise/dropout và ngân sách; hai nhánh chỉ khác cách sử dụng beta. Kiểm count hoặc cùng số seed không tự thay thế bằng chứng này. Đây là mô tả điều kiện bằng chứng, không phải lệnh chạy thêm thí nghiệm.

## 4. Không có bằng chứng rằng V3 không thể tốt hơn

Với cùng tham số G và Dense heads theta, công thức sinh V3 tại beta=0 bằng đúng V2(theta). Startup forward gate của lượt chạy cũng kiểm sự tương đương đó. Vì vậy họ hàm sinh của V3 chứa V2; không có căn cứ nói V3 bị buộc có khả năng biểu diễn thấp hơn.

Điều này không đảm bảo optimizer sẽ tìm lại nghiệm V2 hoặc tìm nghiệm tốt hơn. Nó cũng không chứng minh mọi cách train V3 đều có thể thắng. Nó chỉ ngăn việc dùng ba kết quả thua để khẳng định một giới hạn bất khả thi của kiến trúc.

Kết luận hiện tại: V2 cải thiện Macro-F1 so với original GAN trong M4; V3-A với recipe và ba lượt chạy đã khóa không cải thiện V2; cơ chế distance bias chưa đạt tác dụng endpoint mong muốn; nguyên nhân giảm và giới hạn tốt nhất có thể đạt của V3 chưa được chứng minh.

Dữ liệu kiểm chi tiết: `distance_margin_evidence.csv` / `.json`; script tái tạo: `audit_distance_margin.py`. Không train, không chạy inference và không dùng test để chọn tham số trong phép kiểm này.
