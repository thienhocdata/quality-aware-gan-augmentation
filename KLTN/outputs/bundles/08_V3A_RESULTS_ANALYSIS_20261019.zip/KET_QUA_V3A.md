# V3-A — kết quả đã kiểm tra từ output gốc

**Lượt chạy đã hoàn tất. V3-A không cải thiện full M4 V2 trong thí nghiệm này; giữ V2 làm phương án chính đã có kết quả.**

Đã train đủ 3 seed 42/43/44, mỗi seed 8.000 classifier updates, và test đủ 4.721 mẫu. Tổng thời gian do suite ghi nhận: **3 giờ 27 phút 44 giây** (12.464,11 giây). Không cần train hoặc inference lại để có các bảng dưới đây.

## 1. Kết quả phân loại

Trung bình ± độ lệch chuẩn mẫu qua 3 seed. Các chỉ số phần trăm là 100 × giá trị gốc.

| Phương pháp | OA (%) | AA (%) | Macro-F1 (%) | GM (%) | Kappa |
|---|---:|---:|---:|---:|---:|
| V3-A | 87.609 ± 1.175 | 84.489 ± 1.001 | 81.543 ± 1.701 | 78.208 ± 1.202 | 0.8593 ± 0.0134 |
| V2 Learned-local | 88.251 ± 1.229 | 86.046 ± 1.801 | 83.009 ± 3.015 | 81.793 ± 3.888 | 0.8668 ± 0.0139 |
| Random-local | 88.018 ± 1.199 | 86.016 ± 1.062 | 82.226 ± 3.004 | 81.862 ± 3.919 | 0.8644 ± 0.0134 |
| Original GAN | 87.552 ± 0.444 | 85.783 ± 1.641 | 81.663 ± 2.877 | 82.086 ± 4.027 | 0.8587 ± 0.0053 |
| Matched ROS | 87.143 ± 0.422 | 85.049 ± 0.681 | 81.485 ± 0.967 | 80.575 ± 3.269 | 0.8542 ± 0.0045 |

| Seed | V2 Macro-F1 (%) | V3-A Macro-F1 (%) | V3-A − V2 (điểm %) |
|---:|---:|---:|---:|
| 42 | 86.485 | 83.355 | -3.130 |
| 43 | 81.425 | 81.295 | -0.129 |
| 44 | 81.116 | 79.979 | -1.136 |

**Chênh lệch trung bình: −1,465 điểm phần trăm Macro-F1; V3-A thắng 0/3 so sánh theo seed.** OA trung bình giảm 0,643 điểm %, AA giảm 1,558 điểm %, GM giảm 3,584 điểm %. NLL (0,9857 so với 0,8916) và Brier (0,2149 so với 0,2062) cũng kém hơn; hai chỉ số này càng thấp càng tốt.

Độ lệch chuẩn Macro-F1 của V3-A nhỏ hơn V2, nhưng trung bình thấp hơn. Điều này chưa đủ để gọi V3-A ổn định hơn nói chung và không bù được việc chưa đạt mục tiêu cải thiện.

![So sánh kết quả](V3A_vs_V2_results.png)

## 2. Kiểm tra kỹ thuật và độ đầy đủ

- Đã đọc toàn bộ 175 thành viên ZIP, kiểm CRC và SHA-256; không thấy hỏng file hoặc trùng tên thành viên.
- Source trong ZIP khớp byte với bản notebook đã bàn giao. Frozen M4 không bị sửa.
- Cả ba job có đúng method V3-A, protocol B `50e988fae260`, seed và cấu hình `k=3`, `rho=0.2`, 15 beta; checkpoint cuối và classifier khớp các hash đã khóa.
- Có checkpoint đầy đủ ở 200, 7.500 và 8.000 cho cả ba seed; hai file weights và metadata của từng mốc đều kiểm hash được. Ba classifier H5 cuối đã lưu đủ.
- Báo cáo runtime ghi pilot PASS; seed 42 được restore ở tiến trình mới và kiểm toàn bộ trạng thái native chính xác. Mỗi seed có kiểm 34 route thực đầu tiên, gồm weights, BatchNorm và Adam slots của mạng bị freeze.
- Mỗi seed đủ C=8.000, D=8.000, GC=60.000, GD=60.000 và tổng shared-Adam calls=136.000. Báo cáo train ghi không mở validation/test.
- Có 3 NPZ predictions gồm `y_true`, `y_pred`, `probabilities`, `coords`, confusion matrix; có CSV metrics từng seed và từng lớp. Tính lại tất cả 7 độ đo khớp báo cáo.
- Đã mở lại predictions M4 gốc của đủ 12 model, kiểm nhãn/tọa độ trùng V3 và tính lại baseline; không chỉ tin bảng baseline nhúng trong notebook.
- 1454 điều kiện kiểm tra file/số liệu đã qua. Đây là kiểm tra CPU trên artifact đã lưu, **không phải số lần chạy mô hình**. Không thực hiện TensorFlow restore hoặc forward mới ở máy local.

## 3. Beta và selector đã học gì?

Cả 45 beta (15 head × 3 seed) đều hữu hạn, có thay đổi từ khởi tạo 0 và có tổng bình phương gradient dương. Log ghi 8.000 lần có gradient kết nối cho mỗi beta; điều này không có nghĩa mọi gradient ở cuối train đều khác 0 hoặc hữu ích.

Từ logits thực do Dense head sinh đã lưu trong NPZ, kiểm lại `corrected = raw − beta × standardized_distance` khớp. So sánh giữa mốc 200 và 8.000 dùng đúng cùng anchor IDs, neighbor IDs, noise và standardized distances ở cả ba seed.

| Seed | Entropy ở 200 | Entropy ở 8.000 | Anchor đổi argmax theo noise: 200 → 8.000 |
|---:|---:|---:|---:|
| 42 | 0.120461 | 6.11e-08 | 6/105 → 0/105 |
| 43 | 0.152150 | 2.66e-06 | 8/105 → 0/105 |
| 44 | 0.144424 | 6.46e-07 | 11/105 → 0/105 |

Ở mốc 8.000, max weight trung bình trên probe đều trên 0,9999997. G feature và raw logits vẫn thay đổi theo noise, trong khi weights và patch gần như không đổi theo noise khi giữ anchor cố định.

Distance-bias range trung bình cuối train khoảng **0,087–0,094**, nhỏ hơn nhiều so với raw top-two logit gap trung bình **23,9–30,0**. Trong toàn bộ probe ở cả 200 và 8.000, thêm bias không đổi argmax so với raw logits (0/840 triplet cho mỗi seed/mốc). Điều này chỉ mô tả tác động tức thời của bias ở các điểm đã đo; **không có nghĩa beta không thể tác động vào quỹ đạo huấn luyện**.

Trong 500 C updates cuối (7.500 → 8.000), beta thay đổi tuyệt đối tối đa lần lượt khoảng 8,72×10⁻⁶; 9,18×10⁻⁶; 1,55×10⁻⁴ ở seed 42/43/44. Không có quan sát entropy tại 7.500 trong probe mới này, nên không dùng các beta đó để suy ra entropy 7.500.

**Kết luận cơ chế có giới hạn:** distance bias được triển khai và học được, nhưng trong recipe này chưa ngăn được hiện tượng weights gần one-hot ở endpoint trên các probe đã khóa. Chưa chứng minh đó là nguyên nhân khiến Macro-F1 giảm. Probe chỉ có 7 anchor/head × 8 noise; không thay thế khảo sát toàn bộ support.

![Chẩn đoán selector](V3A_selector_diagnostics.png)

## 4. Lớp nào giảm?

| Seed | Số lớp F1 tăng / giảm / bằng | Giảm F1 lớn nhất | Đóng góp vào chênh Macro-F1 |
|---:|---:|---|---:|
| 42 | 5 / 9 / 2 | Buildings-Grass-Trees-Drives: -29.251 điểm % | -1.828 điểm % |
| 43 | 7 / 8 / 1 | Buildings-Grass-Trees-Drives: -8.670 điểm % | -0.542 điểm % |
| 44 | 5 / 7 / 4 | Grass-pasture-mowed: -13.846 điểm % | -0.865 điểm % |

Đây là phân rã số học từ confusion matrices, không phải giải thích nhân quả. Các lớp rất nhỏ có ít test pixels nên F1/recall dễ dao động. Chi tiết đủ 48 dòng trong `V3_minus_full_M4_V2_per_class.csv`.

## 5. Phạm vi kết luận và quyết định

Baseline đối chiếu là **full M4 Learned-local V2** cùng protocol, train data, graph và ngân sách. Không phải C-only endpoint ablation; không trộn kết quả của hai loại thí nghiệm.

Đây là so sánh với M4 lịch sử, không tuyên bố mọi initialization/chuỗi lấy mẫu/dropout đều paired-identical. Seed 43/44 của M4 cũ có khác phiên bản NumPy và tf-keras; các khác biệt descriptor đã được lưu rõ trong `historical_M4_comparison_limits.json`. Vì vậy không quy toàn bộ chênh lệch riêng cho beta.

Test B đã được xem trước và có chồng lấn không gian. Kết quả này mô tả thí nghiệm hậu nghiệm đã cố định; không xác nhận generalization trên spatial split độc lập, không khẳng định ý nghĩa thống kê từ 3 seed và không giải quyết bài toán leakage.

**Quyết định được dữ liệu hiện tại hỗ trợ:** không chọn V3-A thay V2. Giữ V2 cùng các hạn chế đã biết; trình bày V3-A như một biến thể đã kiểm nghiệm nhưng không cải thiện trong cấu hình này. Lượt này đã trả lời mục tiêu thực nghiệm của V3-A; không cần mở thêm lượt GPU để hoàn tất hoặc cứu kết quả.

Mọi thay đổi beta/loss/temperature sau khi đã đọc các kết quả này sẽ là một ứng viên mới, không sửa lại kết luận của lượt đã hoàn tất.

## 6. File gốc và khả năng phục hồi

- ZIP gốc: `D:\HUIT\Chương trình học\HK1 ( 2026- 2027)\KLTN - GAN\outputs\6. Selector Analysis\V3A_IP_ONERUN_FULL_BACKUP.zip`.
- Dung lượng: 732,398,606 bytes.
- SHA-256: `c18036aff7d19061c5bba0c11e934be159f2f0f0288f89a0b8495f5cbd908f80`.
- ZIP gốc giữ toàn bộ checkpoint Generator/heads/C/D/shared optimizer ở 200/7.500/8.000, classifier cuối, source, telemetry và predictions. Giữ ZIP này để có thể phục hồi mô hình; gói phân tích nhẹ bên cạnh không thay thế checkpoint.
- `received/` là các source/JSON/log/test output nhỏ sao chép nguyên byte để đọc tiện. Các CSV bắt đầu `recomputed_` được tính lại từ predictions gốc; không huấn luyện lại.
- `analyze_backup_cpu.py` tái tạo audit/CSV; `build_report.py` tạo báo cáo/hình. Không có lựa chọn tham số hoặc đánh giá test mới trong hai script này.
