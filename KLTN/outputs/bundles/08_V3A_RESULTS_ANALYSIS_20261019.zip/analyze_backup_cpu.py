"""Audit saved V3-A output. No training, TensorFlow import, or new inference."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent.parent
SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    r"D:\HUIT\Chương trình học\HK1 ( 2026- 2027)\KLTN - GAN\outputs\6. Selector Analysis\V3A_IP_ONERUN_FULL_BACKUP.zip"
)
OLD_TEST = WORKSPACE / "protocol_b_review/m4_test_received_2026-10-16/M4_IP_TEST_20261016T022123Z_f9775859_REPORT.zip"
DELIVERED = WORKSPACE / "protocol_b_review/v3a_one_run_2026-10-19"
METRICS = ("OA", "AA", "Macro_F1", "GM", "Kappa", "NLL", "Brier")
NAMES = ["Alfalfa", "Corn-notill", "Corn-mintill", "Corn", "Grass-pasture", "Grass-trees", "Grass-pasture-mowed", "Hay-windrowed", "Oats", "Soybean-notill", "Soybean-mintill", "Soybean-clean", "Wheat", "Woods", "Buildings-Grass-Trees-Drives", "Stone-Steel-Towers"]
CHECKS = []


def check(name, ok, detail=None):
    CHECKS.append({"check": name, "pass": bool(ok), "detail": detail})
    if not ok:
        raise RuntimeError(name + ": " + str(detail))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(name, rows):
    if not rows:
        return
    with (ROOT / name).open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def arrays(z, name):
    with np.load(io.BytesIO(z.read(name)), allow_pickle=False) as a:
        return {k: a[k].copy() for k in a.files}


def measure(y, prob):
    y = np.asarray(y, dtype=np.int64)
    prob = np.asarray(prob, dtype=np.float64)
    pred = prob.argmax(1)
    cm = np.bincount(y * 16 + pred, minlength=256).reshape(16, 16)
    tp = cm.diagonal().astype(np.float64)
    support, predicted = cm.sum(1), cm.sum(0)
    recall = tp / support
    precision = np.divide(tp, predicted, out=np.zeros(16), where=predicted > 0)
    f1 = 2 * tp / (support + predicted)
    oa = tp.sum() / len(y)
    expected = np.dot(support.astype(np.float64), predicted) / len(y) ** 2
    result = {"OA": float(oa), "AA": float(recall.mean()), "Macro_F1": float(f1.mean()),
              "GM": float(np.exp(np.log(recall).mean())) if np.all(recall > 0) else 0.0,
              "Kappa": float((oa - expected) / (1 - expected)),
              "NLL": float(-np.log(np.clip(prob[np.arange(len(y)), y], 1e-12, 1)).mean()),
              "Brier": float(((prob - np.eye(16)[y]) ** 2).sum(1).mean())}
    return result, cm, precision, recall, f1


def near(name, left, right, atol=1e-12):
    check(name, np.allclose(left, right, rtol=1e-10, atol=atol), {"max_abs_error": float(np.max(np.abs(np.asarray(left) - np.asarray(right))))})


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    inventory, member_hashes = [], {}
    print("Reading ZIP and verifying every member CRC/SHA256 ...", flush=True)
    with zipfile.ZipFile(SOURCE) as z:
        names = z.namelist()
        check("no_duplicate_members", len(names) == len(set(names)))
        for info in z.infolist():
            check("safe_member:" + info.filename, not info.filename.startswith(("/", "\\")) and ".." not in Path(info.filename).parts)
            h = hashlib.sha256()
            with z.open(info) as stream:
                for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                    h.update(block)  # ZipExtFile also checks CRC when fully read.
            member_hashes[info.filename] = h.hexdigest()
            inventory.append({"member": info.filename, "bytes": info.file_size, "compressed_bytes": info.compress_size,
                              "crc32": f"{info.CRC:08x}", "sha256": h.hexdigest()})
        check("all_member_CRC_reads_completed", True)
        read = lambda n: json.loads(z.read(n))
        raw_manifest = read("manifest.json")
        check("global_complete", raw_manifest.get("complete") is True and raw_manifest.get("completed_model_count") == 3)
        check("global_correct_protocol", raw_manifest["protocol_B_id"] == "50e988fae260")
        source_pins = read("source/payload_manifest.json")
        for name, h in source_pins.items():
            check("source_payload_hash:" + name, member_hashes["source/" + name] == h)
            check("matches_delivered_source:" + name, file_sha(DELIVERED / name) == h)
        baseline = read("source/baseline_test_results.json")
        check("original_M4_test_archive_hash", file_sha(OLD_TEST) == baseline["test_report_sha256"])
        test_manifest = read("test_results/manifest.json")
        check("test_complete_3_of_3", test_manifest["complete"] is True and len(test_manifest["predictions"]) == 3)
        testgate = read("test_gate.json")
        write_json("original_completion_manifest.json", raw_manifest)
        write_json("original_test_gate.json", testgate)
        recomputed, perclass, diagnostics, trajectory, comparisons = [], [], [], [], []
        new_predictions = {}
        probe_input_references = {}

        for seed in (42, 43, 44):
            prefix = f"jobs/seed_{seed}/"
            done, contract = read(prefix + "completed.json"), read(prefix + "contract.json")
            pointer, report = read(prefix + "state/latest.json"), read(prefix + "worker_report.json")
            check(f"complete_budget_seed{seed}", done["complete"] and done["c_updates"] == 8000 and done["adam_clock"] == 136000)
            check(f"identity_seed{seed}", contract["seed"] == seed and contract["protocol_B_id"] == "50e988fae260" and contract["method"] == "V3A_SIGNED_ANCHOR_DISTANCE_BIAS_V1")
            check(f"fixed_geometry_seed{seed}", contract["rho"] == .2 and contract["k"] == 3 and contract["beta_count"] == 15)
            check(f"contract_seal_seed{seed}", member_hashes[prefix + "contract.json"] == done["job_contract_sha256"])
            check(f"classifier_seal_seed{seed}", member_hashes[prefix + "classifier.weights.h5"] == done["model_sha256"] == test_manifest["classifier_sha256"][seed - 42])
            check(f"pointer_and_completion_seed{seed}", pointer["c_updates"] == 8000 and pointer["meta_sha256"] == done["native_checkpoint_meta_sha256"] == member_hashes[prefix + "state/ckpt_08000/meta.json"])
            for cp, count in (("pilot_checkpoint/", 200), ("state/ckpt_07500/", 7500), ("state/ckpt_08000/", 8000)):
                meta = read(prefix + cp + "meta.json")
                check(f"native_meta_{seed}_{count}", meta["contract"] == contract and meta["c_updates"] == count and meta["optimizer_clock"] == 17 * count and meta["audit_calls"] == 17 * count)
                check(f"native_inventory_{seed}_{count}", set(meta["weights_hashes"]) == {"weights.index", "weights.data-00000-of-00001"})
                for name, h in meta["weights_hashes"].items():
                    check(f"native_component_{seed}_{count}_{name}", member_hashes[prefix + cp + name] == h)
            check(f"actual_GAN_route_counts_seed{seed}", report["route_counts"] == {"C": 8000, "D": 8000, "GC": 60000, "GD": 60000})
            check(f"train_only_seed{seed}", report["test_opened"] is False and report["validation_opened"] is False)
            start, pilot = read(prefix + "startup_forward_gate.json"), read(prefix + "pilot_gate.json")
            check(f"startup_gate_seed{seed}", start["pass"] is True and start["whole_state_unchanged"] is True)
            check(f"pilot_gate_seed{seed}", pilot["pass"] is True and pilot["c_updates"] == 200 and pilot["optimizer_clock"] == 3400)
            check(f"actual_freeze_route_count_seed{seed}", len(pilot["actual_route_freeze_checks"]) == 34)
            check(f"actual_freeze_slots_seed{seed}", all(v.get("weights_BN_and_Adam_slots_checked") for v in pilot["actual_route_freeze_checks"]))
            beta = read(prefix + "final_beta.json")
            check(f"final_beta_seal_seed{seed}", member_hashes[prefix + "final_beta.json"] == done["final_beta_sha256"])
            check(f"beta_gradients_seed{seed}", beta["beta_gradient_seen"] == [8000] * 15 and np.isfinite(beta["signed_beta"]).all())
            comparisons.append({"seed": seed, **report["original_M4_comparison"]})
            for name in names:
                if name.startswith(prefix + "beta_telemetry/") and name.endswith(".json"):
                    b = read(name)
                    for cls, value, seen, gradient in zip(b["class_ids_original"], b["signed_beta"], b["beta_gradient_seen"], b["beta_gradient_sq_total"]):
                        trajectory.append({"seed": seed, "c_updates": b["c_updates"], "class_id": cls, "beta": value, "gradient_seen": seen, "gradient_sq_cumulative": gradient})
            for count in (200, 8000):
                pn = prefix + f"selector_probes/probe_{count:05d}"
                pm = read(pn + ".json")
                check(f"probe_seal_seed{seed}_{count}", pm["npz_sha256"] == member_hashes[pn + ".npz"] and pm["csv_sha256"] == member_hashes[pn + "_by_class.csv"])
                check(f"probe_frozen_seed{seed}_{count}", pm["all_model_BN_Adam_dropout_audit_state_unchanged"] and pm["extra_optimizer_updates"] == 0 and not pm["test_opened"] and not pm["validation_opened"])
                if count == 8000:
                    check(f"final_probe_seal_seed{seed}", member_hashes[pn + ".json"] == done["selector_probe_8000_manifest_sha256"])
                a = arrays(z, pn + ".npz")
                rows = list(csv.DictReader(io.StringIO(z.read(pn + "_by_class.csv").decode("utf-8"))))
                for h in range(15):
                    tag = f"head_{h:02d}_"
                    w, raw, corr = (a[tag + k].astype(np.float64) for k in ("weights", "selected_raw_logits", "corrected_logits"))
                    b = float(a[tag + "beta"])
                    q = a[tag + "standardized_distance"]
                    for key in ("anchor_ids", "neighbors", "noise8", "standardized_distance"):
                        refkey = (h, key)
                        if refkey not in probe_input_references:
                            probe_input_references[refkey] = a[tag + key]
                        check(f"matched_probe_input_{seed}_{count}_{h}_{key}", np.array_equal(probe_input_references[refkey], a[tag + key]))
                    # Reproduce actual float32 arithmetic before comparing stored logits.
                    expected_corr = a[tag + "selected_raw_logits"] - a[tag + "beta"] * q[:, None, :]
                    near(f"distance_bias_equation_{seed}_{count}_{h}", corr, expected_corr, atol=0)
                    selected = np.take_along_axis(a[tag + "all_raw_logits"], a[tag + "neighbors"][:, None, :], axis=-1)
                    near(f"gather_actual_Dense_logits_{seed}_{count}_{h}", raw, selected, atol=0)
                    # This only verifies weights already produced by the real head;
                    # it does not replace any saved weights with a simulated selector.
                    softmax = np.exp(corr - corr.max(-1, keepdims=True))
                    softmax /= softmax.sum(-1, keepdims=True)
                    near(f"saved_weights_match_actual_logits_{seed}_{count}_{h}", w, softmax, atol=2e-7)
                    near(f"simplex_{seed}_{count}_{h}", w.sum(-1), np.ones((7, 8)), atol=2e-7)
                    check(f"finite_nonnegative_weights_{seed}_{count}_{h}", np.isfinite(w).all() and (w >= 0).all())
                    e = -np.sum(np.where(w > 0, w * np.log(np.clip(w, 1e-300, 1)), 0), -1)
                    near(f"entropy_saved_{seed}_{count}_{h}", e, a[tag + "entropy"])
                    near(f"entropy_csv_{seed}_{count}_{h}", e.mean(), float(rows[h]["entropy_mean"]))
                    arg = w.argmax(-1)
                    gap = np.sort(raw, -1)[..., -1] - np.sort(raw, -1)[..., -2]
                    noise_changes = int(sum(len(np.unique(x)) > 1 for x in arg))
                    diagnostics.append({"seed": seed, "c_updates": count, "class_id": contract["class_order"][h],
                        "head": h, "anchors": 7, "triplets": 56, "beta": b,
                        "entropy_mean": float(e.mean()), "effective_supports_mean": float(np.exp(e).mean()),
                        "max_weight_mean": float(w.max(-1).mean()), "max_weight_min": float(w.max(-1).min()),
                        "noise_changing_anchors": noise_changes, "weight_noise_sd_mean": float(w.std(1).mean()),
                        "raw_corrected_argmax_changes": int(np.sum(raw.argmax(-1) != corr.argmax(-1))),
                        "raw_top2_gap_mean": float(gap.mean()),
                        "distance_bias_range_mean": float(a[tag + "absolute_distance_bias_range"].mean()),
                        "G_feature_noise_RMS_mean": float(a[tag + "G_feature_noise_rms"].mean()),
                        "patch_noise_RMS_mean": float(a[tag + "patch_noise_rms"].mean())})
            pn = f"test_results/V3A_seed{seed}_predictions.npz"
            saved = arrays(z, pn)
            pin = next(p for p in test_manifest["predictions"] if p["seed"] == seed)
            check(f"test_predictions_seal_seed{seed}", member_hashes[pn] == pin["sha256"])
            y, probs = saved["y_true"], saved["probabilities"]
            check(f"test_shape_seed{seed}", y.shape == (4721,) and probs.shape == (4721, 16) and saved["coords"].shape == (4721, 2))
            check(f"probabilities_finite_seed{seed}", np.isfinite(probs).all() and (probs >= 0).all() and (probs <= 1).all())
            near(f"probability_row_sum_seed{seed}", probs.sum(1), np.ones(4721), atol=2e-6)
            result, cm, precision, recall, f1 = measure(y, probs)
            check(f"argmax_prediction_seed{seed}", np.array_equal(probs.argmax(1), saved["y_pred"]))
            check(f"saved_confusion_seed{seed}", np.array_equal(cm, saved["confusion_matrix"]))
            saved_row = next(r for r in csv.DictReader(io.StringIO(z.read("test_results/v3_metrics_by_seed.csv").decode("utf-8"))) if int(r["seed"]) == seed)
            for k in METRICS:
                near(f"saved_metric_seed{seed}_{k}", result[k], float(saved_row[k]))
            recomputed.append({"method": "V3-A", "seed": seed, **result})
            for c in range(16):
                perclass.append({"method": "V3-A", "seed": seed, "class_id": c + 1, "class_name": NAMES[c], "support": int(cm[c].sum()),
                                 "precision": float(precision[c]), "recall": float(recall[c]), "F1": float(f1[c])})
            new_predictions[seed] = saved
        verify = read("jobs/seed_42/pilot_restore_verification.json")
        check("pilot_fresh_process_native_restore_report", verify["pass"] and verify["fresh_process_full_native_read_assert_consumed"] and verify["all_committed_state_hashes_exact"] and verify["extra_optimizer_updates"] == 0)
        # Preserve the already saved analysis payload, not another 0.8GB of weights.
        for n in names:
            if n.startswith(("test_results/", "source/", "logs/")) or (n.endswith(".json") and not "/state/" in n and not "/pilot_checkpoint/" in n):
                target = ROOT / "received" / n
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(n))

    print("Recomputing historical metrics from original saved M4 predictions ...", flush=True)
    with zipfile.ZipFile(OLD_TEST) as old:
        for row in baseline["rows"]:
            arm, seed = row["arm"], row["seed"]
            matching = [n for n in old.namelist() if n.endswith(f"test_results/{arm}/seed_{seed}/predictions.npz")]
            check(f"unique_original_predictions_{arm}_{seed}", len(matching) == 1)
            a = arrays(old, matching[0])
            # Original M4 uses the same saved schema; select the actual stored key.
            pk = "probabilities" if "probabilities" in a else "y_prob"
            yk = "y_true"
            metrics, cm, precision, recall, f1 = measure(a[yk], a[pk])
            check(f"identical_test_labels_{arm}_{seed}", np.array_equal(a[yk], new_predictions[seed]["y_true"]))
            if "coords" in a:
                check(f"identical_test_coords_{arm}_{seed}", np.array_equal(a["coords"], new_predictions[seed]["coords"]))
            check(f"original_CM_matches_reference_{arm}_{seed}", np.array_equal(cm, row["confusion_matrix"]))
            for k in METRICS:
                key = "NLL_recomputed_float64_clip1e-12" if k == "NLL" else "Brier_recomputed_float64_sum16" if k == "Brier" else k
                near(f"original_metric_matches_reference_{arm}_{seed}_{k}", metrics[k], row[key])
            recomputed.append({"method": arm, "seed": seed, **metrics})
            for c in range(16):
                perclass.append({"method": arm, "seed": seed, "class_id": c + 1, "class_name": NAMES[c], "support": int(cm[c].sum()),
                                 "precision": float(precision[c]), "recall": float(recall[c]), "F1": float(f1[c])})

    summary, differences, perclass_differences = [], [], []
    for method in ("V3-A", "learned_local", "random_local", "original_gan", "matched_ros"):
        values = [r for r in recomputed if r["method"] == method]
        r = {"method": method}
        for k in METRICS:
            r[k + "_mean"] = float(np.mean([v[k] for v in values]))
            r[k + "_sample_SD"] = float(np.std([v[k] for v in values], ddof=1))
        summary.append(r)
    for seed in (42, 43, 44):
        v3 = next(r for r in recomputed if r["method"] == "V3-A" and r["seed"] == seed)
        v2 = next(r for r in recomputed if r["method"] == "learned_local" and r["seed"] == seed)
        differences.append({"seed": seed, **{k + "_V3_minus_V2": v3[k] - v2[k] for k in METRICS}})
        for c in range(1, 17):
            a, b = [next(r for r in perclass if r["method"] == m and r["seed"] == seed and r["class_id"] == c) for m in ("V3-A", "learned_local")]
            perclass_differences.append({"seed": seed, "class_id": c, "class_name": NAMES[c - 1], "support": a["support"],
                "V2_F1": b["F1"], "V3_F1": a["F1"], "F1_delta_pp": (a["F1"] - b["F1"]) * 100,
                "Macro_F1_contribution_pp": (a["F1"] - b["F1"]) * 100 / 16,
                "V2_recall": b["recall"], "V3_recall": a["recall"]})
    write_csv("archive_inventory_sha256.csv", inventory)
    write_csv("recomputed_metrics_all_15_models.csv", recomputed)
    write_csv("recomputed_summary_mean_sample_SD.csv", summary)
    write_csv("recomputed_metrics_per_class.csv", perclass)
    write_csv("V3_minus_full_M4_V2_by_seed.csv", differences)
    write_csv("V3_minus_full_M4_V2_per_class.csv", perclass_differences)
    write_csv("selector_probe_recomputed_by_class.csv", diagnostics)
    write_csv("beta_trajectory.csv", sorted(trajectory, key=lambda r: (r["seed"], r["c_updates"], r["class_id"])))
    write_json("historical_M4_comparison_limits.json", comparisons)
    write_json("AUDIT.json", {"status": "PASS", "source_path": str(SOURCE), "source_bytes": SOURCE.stat().st_size,
        "source_sha256": file_sha(SOURCE), "members": len(inventory), "uncompressed_bytes": sum(r["bytes"] for r in inventory),
        "checks_passed": len(CHECKS), "checks_failed": 0, "checks": CHECKS,
        "scope": "CPU only: saved files, CRC/hash/metadata, arithmetic on saved predictions and selector probes. No TensorFlow restore or new inference performed locally.",
        "training_complete": True, "test_complete": True, "runtime_reported_seconds": raw_manifest["elapsed_seconds"],
        "conclusion": "V3-A did not improve historical full M4 V2 in this completed run; Macro-F1 lower on all three seeds. No causal or independent spatial-generalization claim."})
    print(json.dumps({"status": "PASS", "checks": len(CHECKS), "run_seconds": raw_manifest["elapsed_seconds"],
          "V3_Macro_F1": summary[0]["Macro_F1_mean"], "V2_Macro_F1": summary[1]["Macro_F1_mean"],
          "mean_delta_pp": 100 * (summary[0]["Macro_F1_mean"] - summary[1]["Macro_F1_mean"]),
          "deltas_by_seed_pp": [r["Macro_F1_V3_minus_V2"] * 100 for r in differences]}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
