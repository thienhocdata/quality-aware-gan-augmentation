"""Check exact selector margins using saved train-only tensors, without TF."""
from pathlib import Path
import csv
import io
import json
import hashlib
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parent


def softmax(x):
    p = np.exp(x - x.max(-1, keepdims=True))
    return p / p.sum(-1, keepdims=True)


def main():
    audit = json.loads((ROOT / "AUDIT.json").read_text(encoding="utf-8"))
    summary = []
    with zipfile.ZipFile(audit["source_path"]) as z:
        for seed in (42, 43, 44):
            for count in (200, 8000):
                stem = f"jobs/seed_{seed}/selector_probes/probe_{count:05d}"
                payload = z.read(stem + ".npz")
                meta = json.loads(z.read(stem + ".json"))
                assert hashlib.sha256(payload).hexdigest() == meta["npz_sha256"]
                gaps, bounds, corrected_margins, l1, derivatives, changed = [], [], [], [], [], []
                with np.load(io.BytesIO(payload), allow_pickle=False) as a:
                    for head in range(15):
                        p = f"head_{head:02d}_"
                        raw = a[p + "selected_raw_logits"].astype(np.float64)
                        corr = a[p + "corrected_logits"].astype(np.float64)
                        q = np.broadcast_to(a[p + "standardized_distance"].astype(np.float64)[:, None, :], raw.shape)
                        beta = float(a[p + "beta"])
                        top = raw.argmax(-1)
                        qt = np.take_along_axis(q, top[..., None], -1)
                        bound = np.max(np.abs(beta * (qt - q)), -1)
                        ordered = np.sort(raw, -1)
                        gap = ordered[..., -1] - ordered[..., -2]
                        top_corrected = np.take_along_axis(corr, top[..., None], -1)
                        mask = np.eye(3, dtype=bool)[top]
                        margin = np.min(np.where(mask, np.inf, top_corrected - corr), -1)
                        old, new = softmax(raw), softmax(corr)
                        w = a[p + "weights"].astype(np.float64)
                        assert np.allclose(w, new, atol=2e-7, rtol=0)
                        dw = new * ((new * q).sum(-1, keepdims=True) - q)
                        gaps.extend(gap.ravel()); bounds.extend(bound.ravel())
                        corrected_margins.extend(margin.ravel())
                        l1.extend(np.abs(new - old).sum(-1).ravel())
                        derivatives.extend(np.abs(dw).max(-1).ravel())
                        changed.extend((raw.argmax(-1) != corr.argmax(-1)).ravel())
                gap, bound = np.array(gaps), np.array(bounds)
                row = {"seed": seed, "c_updates": count, "observations": len(gap),
                       "observations_provably_same_argmax_gap_gt_bound": int((gap > bound).sum()),
                       "observed_argmax_changes": int(np.sum(changed)),
                       "raw_top2_gap_min": float(gap.min()), "distance_adverse_bound_max": float(bound.max()),
                       "gap_minus_bound_min": float((gap - bound).min()),
                       "bound_over_gap_max": float((bound / gap).max()),
                       "corrected_margin_above_competitors_min": float(np.min(corrected_margins)),
                       "L1_weight_difference_vs_beta0_mean": float(np.mean(l1)),
                       "L1_weight_difference_vs_beta0_max": float(np.max(l1)),
                       "max_abs_softmax_derivative_wrt_beta": float(np.max(derivatives))}
                summary.append(row)
    record = {"scope": "Saved train-only logits/weights only; no new TensorFlow forward, classifier inference, training, or model selection.",
              "condition": "For each observed raw winner t: m = l_t - max_{j!=t} l_j; b = max_j |beta*(q_t-q_j)|. If m>b, the distance term cannot change that winner on this fixed input.",
              "caveat": "This is a fixed-endpoint ranking statement, not proof of unchanged training trajectory or an upper bound on test Macro-F1. beta=0 reproduces the V2 formula; no architectural impossibility of matching/improving V2 is established.",
              "rows": summary}
    (ROOT / "distance_margin_evidence.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (ROOT / "distance_margin_evidence.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0])); w.writeheader(); w.writerows(summary)
    print(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
