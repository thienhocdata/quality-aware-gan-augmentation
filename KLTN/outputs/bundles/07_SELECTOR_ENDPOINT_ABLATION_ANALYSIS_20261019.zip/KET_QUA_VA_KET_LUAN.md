# Controlled Endpoint Ablation — kết quả đã đối chiếu

Ngày đọc và kiểm tra: 19/10/2026. Protocol B `50e988fae260`.

**Đã hoàn tất sáu C-only job. Kết quả dùng được; không cần train lại để hoàn tất thí nghiệm này.**

Nguồn: `selector_endpoint_ablation_clean_backup.zip`, 130.717.579 bytes; SHA-256 `7dcdcbdd1a62948a704162334c992b35674cdbcffd38843e5360426b319fc062`.

## Kết quả chính

| Cặp G/C seed | Learned weights: Macro-F1 (%) | Random-one-fixed: Macro-F1 (%) | Learned − Random (điểm phần trăm) |
|---|---:|---:|---:|
| 42 | 82,512 | 82,857 | −0,345 |
| 43 | 83,510 | 78,067 | +5,442 |
| 44 | 80,466 | 78,429 | +2,038 |
| Trung bình ± SD mẫu | **82,163 ± 1,551** | **79,784 ± 2,667** | **+2,379** |

SD mẫu dùng `ddof=1`, ba seed; SD của ba paired differences là 2,909 điểm phần trăm. Learned thắng 2/3 cặp, seed 42 thua. Các giá trị delta 0,054425 trong CSV gốc là trên thang 0–1, tương ứng 5,4425 điểm phần trăm.

| Độ đo | Learned: trung bình ± SD mẫu | Random-one-fixed: trung bình ± SD mẫu |
|---|---:|---:|
| OA (%) | 87,192 ± 0,903 | 86,705 ± 1,661 |
| AA (%) | 85,263 ± 1,221 | 83,439 ± 1,854 |
| Macro-F1 (%) | 82,163 ± 1,551 | 79,784 ± 2,667 |
| GM (%)¹ | 79,907 ± 4,580 | 76,269 ± 1,454 |
| Kappa | 0,854850 ± 0,010282 | 0,849095 ± 0,018714 |
| NLL ↓ | 1,034228 ± 0,185781 | 0,993130 ± 0,128543 |
| Brier ↓ | 0,225038 ± 0,017608 | 0,228192 ± 0,028805 |

¹ GM được tính bổ sung từ geometric mean recall của đủ 16 lớp; không có trong CSV gốc. NLL giữ đúng clipping 1e−12 của runner. Không chỉ chọn các độ đo có lợi: NLL trung bình của Learned kém hơn, dù Macro-F1 cao hơn.

## Câu hỏi nghiên cứu được trả lời

**Tại ba checkpoint cuối đã kiểm tra, dùng quy tắc learned weighting đã đóng băng để tạo mẫu bổ sung mang lại Macro-F1 trung bình cao hơn quy tắc chọn ngẫu nhiên một neighbor cố định, khi huấn luyện các C mới theo lịch ghép cặp.** Đây là bằng chứng thực nghiệm tích cực cho giá trị của quy tắc weighting endpoint trong phạm vi Protocol B và ba cặp này.

Hiện tượng trọng số gần one-hot, đã quan sát ở chẩn đoán trước, không đồng nghĩa lựa chọn nguồn vô ích. Kết quả hiện tại cho thấy lựa chọn học được có thể hữu ích so với đối chứng one-neighbor ngẫu nhiên đã khóa. Không suy rộng thành luôn thắng, noise có ích, soft weighting hơn hard weighting, hoặc toàn bộ GAN tốt hơn các phương pháp khác.

Riêng seed 43: Learned thắng F1 ở 14/16 lớp, hòa một lớp và thua một lớp. Lớp 15 Buildings–Grass–Trees–Drives đóng góp lớn nhất: F1 56,180% so với 15,267%; recall 50/99 so với 10/99. Lớp này đóng góp 2,558 trong tổng 5,442 điểm Macro-F1 tăng, khoảng 47%; tổng đóng góp các lớp còn lại vẫn dương. Điều này không xác định nguyên nhân kết quả M4 seed 43 cũ; classifier và quá trình huấn luyện của hai phép so sánh khác nhau.

## Phạm vi và giới hạn

- Đây là so sánh endpoint sau khi test B đã được xem; không phải kiểm định mù.
- Protocol B vẫn có chồng lấn không gian. Không dùng thí nghiệm này để kết luận đã xử lý leakage hoặc ước lượng mức tăng accuracy do leakage.
- G seed và C seed được ghép cùng số; random map cũng thay theo seed. Chỉ có ba block, chưa tách biến thiên do từng nguồn và chưa chứng minh độ ổn định rộng hơn.
- Learned dùng soft weights thật, đối chứng chọn đúng một neighbor. Hiệu ứng so sánh là toàn bộ quy tắc weighting endpoint, không chỉ danh tính neighbor trong một phép can thiệp đơn biến.
- Không cô lập lợi ích của adversarial training: Learned G đã được huấn luyện trước, còn thí nghiệm hiện tại chỉ huấn luyện C mới.
- Random-local trong M4 cũ dùng Dirichlet mixing; Random-one-fixed hiện tại là đối chứng khác. Không gộp hai bảng thành cùng một phép ablation.

## Những gì đã kiểm tra

311 kiểm tra CPU đạt: CRC ZIP; SHA source/contract/classifier/native checkpoint; cả hai thành phần native tại 7.500 và 8.000 của sáu C; counters, pointer và paired traces; provenance G gốc; khởi tạo C/Adam; dự đoán và nhãn/tọa độ test khớp master split B gốc; xác suất hữu hạn và argmax khớp; metrics và per-class khớp CSV.

Source thực tế đã sửa `Checkpoint.read()` và giữ kiểm hash từng biến G/head trước khi freeze, `training=False`, cùng phép trộn V2. Logs cho thấy đủ sáu job hoàn tất trước finalize. Các vấn đề phòng ngắt phiên trong runner không làm hỏng lượt hoàn tất này; file native hiện tại đã được kiểm lại đầy đủ.

Lần đọc output này không chạy TensorFlow, không restore mô hình để forward, không inference và không huấn luyện. Kiểm hash checkpoint không được gọi là đã tái kiểm numerical restore hoặc numerical equivalence H5–native trên máy này. Dòng log `use_unbounded_threadpool` không chặn lượt finalize đã hoàn tất.

## Hồ sơ kết quả

- `original_final_evaluation/`: CSV/manifest gốc, giữ nguyên bytes.
- `saved_predictions/`: sáu NPZ dự đoán gốc, giữ nguyên bytes và đã đối chiếu SHA.
- `metrics_per_seed_with_GM.csv`, `summary_mean_sample_SD.csv`, `paired_differences_recomputed.csv`: metrics tính lại trên CPU.
- `per_class_recomputed.csv`, `per_class_paired_contributions.csv`: phân tích đủ lớp/seed.
- `confusion_matrices/`: sáu ma trận CSV và NPY; hàng là nhãn thật, cột là nhãn dự đoán, thứ tự 1–16.
- `AUDIT_RESULT.json`, `analyze_saved_output.py`: chi tiết kiểm tra và mã tái lập.

Có thể chốt thí nghiệm endpoint hiện tại và viết kết quả/phân tích từ hồ sơ này. Không cần thêm lượt GPU để bổ sung các output vừa nêu. Giữ nguyên ZIP nguồn làm bản sao đầy đủ sáu classifier/checkpoint; ZIP phân tích là hồ sơ nhỏ bổ sung, không chứa lại các weights.
