"""Audit saved endpoint ablation artifacts and derive reports. No TF/inference/train."""
from pathlib import Path
import csv
import hashlib
import io
import json
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = Path(r"D:/HUIT/Chương trình học/HK1 ( 2026- 2027)/KLTN - GAN/outputs/6. Selector Analysis/selector_endpoint_ablation_clean_backup.zip")
SEEDS = (42, 43, 44)
METHODS = ("learned_weights", "random_one_fixed")
METRICS = ("OA", "AA", "Macro_F1", "GM", "Kappa", "NLL", "Brier")
CLASSES = ("Alfalfa", "Corn-notill", "Corn-mintill", "Corn", "Grass-pasture", "Grass-trees", "Grass-pasture-mowed", "Hay-windrowed", "Oats", "Soybean-notill", "Soybean-mintill", "Soybean-clean", "Wheat", "Woods", "Buildings-Grass-Trees-Drives", "Stone-Steel-Towers")
checks = []


def check(condition, name):
    checks.append({"check": name, "pass": bool(condition)})
    if not condition:
        raise RuntimeError(name)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def csv_rows(z, name):
    return list(csv.DictReader(io.StringIO(z.read(name).decode("utf-8"))))


def get_json(z, name):
    return json.loads(z.read(name))


def calculate(y, pred, prob):
    cm = np.zeros((16, 16), dtype=np.int64)
    np.add.at(cm, (y, pred), 1)
    tp = np.diag(cm)
    support = cm.sum(axis=1)
    predicted = cm.sum(axis=0)
    precision = np.divide(tp, predicted, out=np.zeros(16), where=predicted != 0)
    recall = tp / support
    f1 = np.divide(2 * tp, support + predicted, out=np.zeros(16), where=(support + predicted) != 0)
    oa = float(tp.sum() / len(y))
    expected = float(np.dot(support.astype(float), predicted) / len(y) ** 2)
    metrics = {"OA": oa, "AA": float(recall.mean()), "Macro_F1": float(f1.mean()),
               "GM": float(np.exp(np.log(recall).mean())) if np.all(recall > 0) else 0.0,
               "Kappa": (oa - expected) / (1 - expected),
               "NLL": float(-np.log(np.maximum(prob[np.arange(len(y)), y], 1e-12)).mean()),
               "Brier": float(np.square(prob - np.eye(16, dtype=np.float32)[y]).sum(axis=1).mean())}
    per_class = [{"class_id": i + 1, "class_name": CLASSES[i], "support": int(support[i]),
                  "precision": float(precision[i]), "recall": float(recall[i]), "F1": float(f1[i])} for i in range(16)]
    return metrics, per_class, cm


def main():
    archive_hash = file_digest(SOURCE)
    rows, per_class, pairs, paired_class, job_audits = [], [], [], [], []
    predictions = {}
    with zipfile.ZipFile(SOURCE) as z, zipfile.ZipFile(ROOT / "KLTN_clean/checkpoints/03_ENDGAME_LEARNED_LOCAL_6_CKPTS.zip") as original:
        check(z.testzip() is None, "All received ZIP members pass CRC")
        manifest = get_json(z, "final_evaluation/manifest.json")
        check(manifest["status"] == "COMPLETE_6_OF_6", "Final six-model manifest complete")
        runner_hash = digest(z.read("endpoint_ablation_runner_clean_r3.py"))
        saved = csv_rows(z, "final_evaluation/results.csv")
        saved_pc = csv_rows(z, "final_evaluation/per_class.csv")
        saved_pairs = csv_rows(z, "final_evaluation/paired_differences.csv")
        source_meta = {}
        for seed in SEEDS:
            member = next(n for n in original.namelist() if n.endswith(f"seed_{seed}/state/ckpt_08000/meta.json"))
            source_meta[seed] = (digest(original.read(member)), get_json(original, member))

        # Only labels and coordinates from the pinned B master; never load test features.
        with zipfile.ZipFile(ROOT / "KLTN_clean/data/01_PROTOCOL_B_SOURCE.zip") as b:
            prefix = "KLTN_HyperGAMO_B_50e988fae260/"
            bm_bytes = b.read(prefix + "manifest.json")
            check(digest(bm_bytes) == "41486ba39177e36f32e09c61cff870f4086a94c7b55f39db9dbe4b92093d6e67", "Original B manifest pin")
            bm = json.loads(bm_bytes)
            master_bytes = b.read(prefix + "B_master_split.npz")
            check(digest(master_bytes) == bm["master_split_sha256"], "Original B master split hash")
            with np.load(io.BytesIO(master_bytes), allow_pickle=False) as d:
                coords_b = d["coords_test"].copy()
                truth_b = d["standard_gt"][coords_b[:, 0], coords_b[:, 1]].astype(np.int64) - 1
            side = get_json(b, prefix + "final_data/test_4721_LOCKED.npz.json")
            check(side["sha256"] == manifest["test_source"]["sha256"], "Recorded test cache SHA agrees with original B sidecar")

        contracts, final_meta = {}, {}
        for seed in SEEDS:
            for method in METHODS:
                label = f"G{seed}_C{seed}/{method}"
                job = f"jobs/{label}"
                c = get_json(z, job + "/contract.json")
                done = get_json(z, job + "/completed.json")
                check(c["runner_sha"] == runner_hash, label + " embedded runner hash")
                check(c["G_seed"] == c["C_seed"] == seed and c["method"] == method, label + " identity")
                check(done["status"] == "COMPLETE" and done["c_updates"] == 8000 and done["adam_clock"] == 136000, label + " complete budget")
                for path, field in (("classifier.weights.h5", "classifier_sha"), ("contract.json", "contract_sha"), ("state/ckpt_08000/meta.json", "checkpoint_meta_sha")):
                    check(digest(z.read(job + "/" + path)) == done[field], label + " " + path + " SHA")
                ptr = get_json(z, job + "/state/latest.json")
                check(ptr["name"] == "ckpt_08000" and ptr["c_updates"] == 8000 and ptr["meta_sha256"] == done["checkpoint_meta_sha"], label + " latest pointer")
                for updates in (7500, 8000):
                    cp = job + f"/state/ckpt_{updates:05d}"
                    m = get_json(z, cp + "/meta.json")
                    check(m["contract"] == c, label + f" {updates} native contract")
                    check(m["next_loop"] * 2 == m["c_updates"] == updates and m["clock"] == 17 * updates, label + f" {updates} counters")
                    check(m["state"]["audit_calls"] == m["state"]["dropout_calls"] == updates and m["state"]["clock"] == m["clock"], label + f" {updates} audit/dropout/clock")
                    check(set(m["weights_hashes"]) == {"weights.index", "weights.data-00000-of-00001"}, label + f" {updates} native components")
                    for fname, sha in m["weights_hashes"].items():
                        check(digest(z.read(cp + "/" + fname)) == sha, label + f" {updates} " + fname + " SHA")
                check(m["paired_trace"] == done["paired_consumption_trace"], label + " final consumed trace")
                check(done["frozen_weights_unchanged"] is True and done["test_opened"] is False and c["training_test_access"] is False, label + " freeze and train-only flags")
                orig_sha, orig = source_meta[seed]
                check(c["source_checkpoint_meta_sha"] == orig_sha and c["source_native_hashes"] == orig["weights_hashes"], label + " original M4 G checkpoint binding")
                check(c["train_X_sha"] == orig["contract"]["train_X_sha256"] and c["train_y_sha"] == orig["contract"]["train_y_sha256"] and c["graph_sha"] == orig["contract"]["graph_sha256"], label + " original final train and graph binding")
                contracts[seed, method], final_meta[seed, method] = c, m
                pred_member = f"final_evaluation/G{seed}_{method}_predictions.npz"
                pb = z.read(pred_member)
                pin = next(p for p in manifest["predictions"] if p["seed"] == seed and p["method"] == method)
                check(digest(pb) == pin["sha256"], label + " saved predictions SHA")
                with np.load(io.BytesIO(pb), allow_pickle=False) as d:
                    y, pred, prob, coords = (d[k].copy() for k in ("y_true", "y_pred", "probabilities", "coords"))
                check(prob.shape == (4721, 16) and np.isfinite(prob).all() and np.all((prob >= 0) & (prob <= 1)) and np.allclose(prob.sum(1), 1, atol=2e-6), label + " probability integrity")
                check(np.array_equal(prob.argmax(1), pred), label + " argmax prediction agreement")
                check(np.array_equal(y, truth_b) and np.array_equal(coords, coords_b), label + " exact original B test truth and order")
                values, pc, cm = calculate(y, pred, prob)
                old = next(r for r in saved if int(r["G_seed"]) == seed and r["method"] == method)
                for metric in METRICS:
                    if metric in old:
                        check(np.isclose(values[metric], float(old[metric]), atol=2e-7, rtol=0), label + " recompute " + metric)
                for r in pc:
                    prior = next(v for v in saved_pc if int(v["G_seed"]) == seed and v["method"] == method and int(v["class_id"]) == r["class_id"])
                    check(all(np.isclose(r[k], float(prior[k]), atol=1e-12, rtol=0) for k in ("support", "precision", "recall", "F1")), label + " recompute class " + str(r["class_id"]))
                rows.append({"G_seed": seed, "C_seed": seed, "method": method, **values})
                per_class.extend({"G_seed": seed, "C_seed": seed, "method": method, **r} for r in pc)
                cmdir = OUT / "confusion_matrices"
                cmdir.mkdir(exist_ok=True)
                np.savetxt(cmdir / f"G{seed}_{method}.csv", cm, fmt="%d", delimiter=",", header=",".join(str(i) for i in range(1, 17)), comments="")
                np.save(cmdir / f"G{seed}_{method}.npy", cm)
                predictions[seed, method] = (y, pred)
                pd = OUT / "saved_predictions"
                pd.mkdir(exist_ok=True)
                (pd / Path(pred_member).name).write_bytes(pb)
                job_audits.append({"seed": seed, "method": method, "C_updates": 8000, "clock": 136000, "elapsed_seconds": done["elapsed_seconds"], "classifier_sha256": done["classifier_sha"], "paired_trace": done["paired_consumption_trace"]})

        for seed in SEEDS:
            a, b = (contracts[seed, method] for method in METHODS)
            common = set(a) - {"method"}
            check(all(a[k] == b[k] for k in common), f"Seed {seed} all paired contract fields except method equal")
            check(final_meta[seed, METHODS[0]]["paired_trace"] == final_meta[seed, METHODS[1]]["paired_trace"], f"Seed {seed} actual paired consumed inputs equal")
            check(a["C_init"] == get_json(z, f"init_seed_{seed}.json") and a["C_init"]["Adam_clock"] == 0, f"Seed {seed} fresh matched initialization")
            l, r = (next(v for v in rows if v["G_seed"] == seed and v["method"] == method) for method in METHODS)
            pair = {"G_seed": seed, "C_seed": seed, **{k: l[k] - r[k] for k in METRICS}}
            y, lp = predictions[seed, METHODS[0]]
            _, rp = predictions[seed, METHODS[1]]
            pair.update(learned_only_correct=int(np.sum((lp == y) & (rp != y))), random_only_correct=int(np.sum((lp != y) & (rp == y))))
            prior = next(v for v in saved_pairs if int(v["G_seed"]) == seed)
            check(all(np.isclose(pair[k], float(prior["learned_minus_random_" + k]), atol=2e-7, rtol=0) for k in METRICS if "learned_minus_random_" + k in prior), f"Seed {seed} paired differences")
            pairs.append(pair)
            for i in range(1, 17):
                p, q = (next(v for v in per_class if v["G_seed"] == seed and v["method"] == method and v["class_id"] == i) for method in METHODS)
                paired_class.append({"seed": seed, "class_id": i, "class_name": CLASSES[i-1], "support": p["support"], "learned_F1": p["F1"], "random_F1": q["F1"], "F1_difference_pp": 100 * (p["F1"] - q["F1"]), "contribution_to_macro_difference_pp": 100 * (p["F1"] - q["F1"]) / 16})
        for n in z.namelist():
            if n.startswith("final_evaluation/") and not n.endswith(".npz"):
                dest = OUT / "original_final_evaluation" / Path(n).name
                dest.parent.mkdir(exist_ok=True)
                dest.write_bytes(z.read(n))

    summary = []
    for metric in METRICS:
        l = np.array([r[metric] for r in rows if r["method"] == METHODS[0]])
        r = np.array([r[metric] for r in rows if r["method"] == METHODS[1]])
        d = l - r
        summary.append({"metric": metric, "learned_mean": float(l.mean()), "learned_sample_SD": float(l.std(ddof=1)), "random_mean": float(r.mean()), "random_sample_SD": float(r.std(ddof=1)), "paired_mean_difference": float(d.mean()), "paired_sample_SD": float(d.std(ddof=1)), "units": "fraction" if metric in ("OA", "AA", "Macro_F1", "GM") else "raw"})
    write_csv(OUT / "metrics_per_seed_with_GM.csv", rows)
    write_csv(OUT / "summary_mean_sample_SD.csv", summary)
    write_csv(OUT / "paired_differences_recomputed.csv", pairs)
    write_csv(OUT / "per_class_recomputed.csv", per_class)
    write_csv(OUT / "per_class_paired_contributions.csv", paired_class)
    report = {"status": "PASS_SAVED_ARTIFACT_AUDIT", "date": "2026-10-19", "source_zip": str(SOURCE), "source_bytes": SOURCE.stat().st_size, "source_sha256": archive_hash, "checks_passed": len(checks), "checks": checks, "jobs": job_audits, "summary": summary, "pairs": pairs, "scope": "Recompute saved predictions and check saved file/metadata integrity; no TensorFlow restore, inference or training", "interpretation": {"endpoint_ablation_complete": True, "positive_mean_macro_F1": True, "wins_of_three": 2, "post_hoc_protocol_B": True, "independent_spatial_generalization_claimed": False, "whole_GAN_causal_benefit_claimed": False, "native_h5_numerical_equivalence_retested": False, "GM": "derived from geometric mean of 16 per-class recalls; absent in original results CSV", "confusion_matrix_axes": "rows=true class IDs 1..16, columns=predicted class IDs 1..16"}}
    write_json(OUT / "AUDIT_RESULT.json", report)
    print(json.dumps({"status": report["status"], "checks": len(checks), "source_sha256": archive_hash, "summary": summary, "pairs": pairs}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
