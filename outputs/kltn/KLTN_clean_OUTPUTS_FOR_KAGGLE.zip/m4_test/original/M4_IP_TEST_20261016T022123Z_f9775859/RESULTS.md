# M4 — Protocol B test, four arms × three seeds

Mean ± sample SD (ddof=1), three seeds. OA/AA/Macro-F1/GM in %, Kappa 0–1.
This is the same within-scene B test previously evaluated for older B models; no leakage-free or new blind-test claim.

| Method | OA (%) | AA (%) | Macro-F1 (%) | GM (%) | Kappa |
|---|---:|---:|---:|---:|---:|
| Original GAN | 87.552 ± 0.444 | 85.783 ± 1.641 | 81.663 ± 2.877 | 82.086 ± 4.027 | 0.8587 ± 0.0053 |
| Matched ROS | 87.143 ± 0.422 | 85.049 ± 0.681 | 81.485 ± 0.967 | 80.575 ± 3.269 | 0.8542 ± 0.0045 |
| Random-local | 88.018 ± 1.199 | 86.016 ± 1.062 | 82.226 ± 3.004 | 81.862 ± 3.919 | 0.8644 ± 0.0134 |
| Learned-local V2 | 88.251 ± 1.229 | 86.046 ± 1.801 | 83.009 ± 3.015 | 81.793 ± 3.888 | 0.8668 ± 0.0139 |
