# Learned-local V2 — 3 seeds: hậu nghiệm tại checkpoint cuối

Trạng thái: **COMPLETE_3_SEEDS**. Protocol B `50e988fae260`, 8.000 C updates.

## Số liệu mô tả

Mỗi số dưới đây là trung bình đều qua 15 lớp có learned head; trong mỗi lớp lấy đều các anchor và cùng ngân sách noise.

| Seed | H (nats) | mean exp(H) | max weight | noise JSD | weight noise RMS | patch noise RMS/coordinate |
|---:|---:|---:|---:|---:|---:|---:|
| 42 | 2.691301e-07 | 1 | 1 | 1.198561e-08 | 3.623919e-08 | 1.354356e-09 |
| 43 | 9.891458e-07 | 1.000001 | 0.9999999 | 6.359691e-08 | 1.8655e-07 | 6.736649e-09 |
| 44 | 3.537666e-07 | 1 | 1 | 2.320989e-08 | 6.862139e-08 | 2.496212e-09 |

## Tái hiện implementation M4

- Dựng G và head từ nguyên văn các hàm source M4 đã kiểm SHA; đúng 50 tensor G/head gồm 8 buffer BatchNorm.
- Đúng train final 5.528 mẫu và PCA cache của B; đúng class rank, support row order, kNN Euclidean float64, k=3 và rho=0.2.
- Dùng logits của Dense được khôi phục; gather ba neighbor rồi tf.nn.softmax đúng local_mix. Forward training=False tương ứng tuyến sinh fake cho C.
- Không dựng C/D hoặc Adam. Chỉ khôi phục phần G/head; không tuyên bố restore toàn bộ training state.

## Lựa chọn phân tích hậu nghiệm

- Toàn bộ 4.138 anchor thiểu số; 64 noise N(0,1) mỗi lớp, analysis seed 20261016. Cùng anchor và noise giữa 42/43/44; không phải replay noise đã dùng trong training.
- G không phụ thuộc anchor: tính feature và Dense logits một lần cho mỗi noise/lớp rồi dùng đúng mask của từng anchor. Kiểm đầu ra head gốc trên anchor đầu/giữa/cuối mỗi lớp với toàn bộ noise.
- Entropy và exp(H) xét riêng ba neighbor. Mixture entropy được ghi riêng cho [0.8,0.2*w1,0.2*w2,0.2*w3].
- Patch noise RMS dùng Gram matrix của ba neighbor trong PCA space; đối chiếu với output head float32 ở tập anchor cố định. Chỉ bỏ sai số tổng xác suất float32 khi làm phép tính hình học, không sửa trọng số được lưu.
- So sánh usage của từng support với uniform trên cùng graph; không dùng 1/Nc vì indegree khác nhau.

## Chưa thể suy luận

- Trọng số khác uniform hoặc phụ thuộc noise chưa chứng minh chúng có ích cho classification. Trọng số gần cố định cũng chưa chứng minh mô hình hỏng.
- Không có trajectory trọng số trong training: không suy ngược thời điểm học, collapse hay hội tụ từ endpoint này.
- Khác biệt của seed 43 trong báo cáo này chỉ là mô tả; không xác định nguyên nhân Macro-F1 kém Random-local. Không chạy classifier hoặc dùng test/validation để chọn tham số.
- Noise được chia sẻ giữa anchor tạo phụ thuộc; không coi từng anchor/noise là một lần huấn luyện độc lập và không tính p-value kiểu đó.
- Lớp 11 Soybean-mintill không có learned head: N/A. Kết quả chỉ áp dụng cho inference-mode BN và tập noise hữu hạn này.

## File chính

`per_class_metrics.csv`, `per_anchor_metrics.csv`, `neighbor_rank_summary.csv`, `global_support_usage.csv`, `matched_seed_pair_deltas.csv`, `figures/`, `seed_*/weights/class_*.npz` và các JSON xác minh.
